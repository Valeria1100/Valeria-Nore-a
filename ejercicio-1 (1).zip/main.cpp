/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
    int num1, num2, resultado;
    cout<< "digite el primer numero";
    cin>> num1;
    cout<< "digite el segundo numero";
    cin>>num2;
    resultado=num1+num2;
    cout<< "el resultado de la operacion es de"<<resultado<<endl;
       resultado=num1-num2;
    cout<< "el resultado de la operacion es de"<<resultado<<endl;
       resultado=num1*num2;
    cout<< "el resultado de la operacion es de"<<resultado<<endl;
       resultado=num1/num2;
    cout<< "el resultado de la operacion es de"<<resultado<<endl;
       resultado=num1%num2;
    cout<< "el resultado de la operacion es de"<<resultado<<endl;
}